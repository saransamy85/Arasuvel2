    <section id="header">
           <div class="menu">
            <div class="logo">
                <img src="<?php echo e(asset('images/logo3.png')); ?>">
            </div>
            <div class="menulist" id="menulist">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(url('about')); ?>">About</a></li>
                    <li><a href="<?php echo e(route('product')); ?>">Product</a></li>
                    <li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <button class="icon" id="icon">
                <i class="fa-solid fa-bars"></i>
            </button>
           </div>
    </section><?php /**PATH E:\Laravel_2025\arasuvelroofings\resources\views/components/headernav.blade.php ENDPATH**/ ?>