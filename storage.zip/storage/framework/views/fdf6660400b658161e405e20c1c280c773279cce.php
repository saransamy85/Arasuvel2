<section id="footer">
        <div class="p-3">
            <div class="ft-cont">
                <div class="row">
                    <div class="col-4">
                        <ul>
                            <li>Help</li>
                            <li>Contact us</li>
                            <li>Home</li>
                            <li>About</li>
                        </ul>
                    </div>
                    <div class="col-4">
                        <ul>
                            <li>Subscribe</li>
                            <li><input type="email" class="form-control" placeholder="Email Address"></li>
                            <li><i class="fa-brands fa-whatsapp" style="color: #0a7b17;"></i>&nbsp;&nbsp;WhatsApp</li>
                            <li>About</li>
                        </ul>
                    </div>
                    <div class="col-4">
                        <ul>
                            <li><i class="fa-brands fa-facebook" style="color: #0659ea;"></i>&nbsp;&nbsp;Facebook</li>
                            <li><i class="fa-brands fa-instagram" style="color: #d049cb;"></i>&nbsp;&nbsp;Instagram</li>
                            <li><i class="fa-brands fa-linkedin" style="color: #74C0FC;"></i>&nbsp;&nbsp;LinkedIn</li>
                            <li><i class="fa-brands fa-pinterest" style="color: #e407bf;"></i>&nbsp;&nbsp;Pintrest</li>
                        </ul>
                    </div>
                </div>
            </div>
            <h6 class="text-center">Copyrights 2025 @ Arasuvel Roofings. All Rights Reserved.</h6>
        </div>
    </section><?php /**PATH E:\Laravel_2025\arasuvelroofings\resources\views/components/footer.blade.php ENDPATH**/ ?>