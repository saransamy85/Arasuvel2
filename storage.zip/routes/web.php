<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\homecontroller;

Route::get('/',[homecontroller::class,'index'])->name('home');
Route::get('/about',[homecontroller::class,'about'])->name('about');
Route::get('/gallery',[homecontroller::class,'gallery'])->name('gallery');
Route::get('/products',[homecontroller::class,'product'])->name('product');
